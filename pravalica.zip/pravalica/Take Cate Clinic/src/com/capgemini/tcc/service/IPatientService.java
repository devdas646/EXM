package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.TackCareClinicException;

public interface IPatientService {
	

	int addPatientDetails( PatientBean patientBean) throws TackCareClinicException;
	PatientBean getPatientDetails(int patientId) throws TackCareClinicException;

}
