package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientADAO;
import com.capgemini.tcc.exception.TackCareClinicException;

public class PatientService implements IPatientService {
	

	PatientADAO patientdao = new PatientADAO();

	@Override
	public int addPatientDetails(PatientBean patientBean)throws TackCareClinicException {
		
		// TODO Auto-generated method stub
		return patientdao.addPatientDetails(patientBean);
	}

	@Override
	public PatientBean getPatientDetails(int patientId)throws TackCareClinicException {
			
		// TODO Auto-generated method stub
		return patientdao.getPatientDetails(patientId);
	}

}
