package com.capgemini.test;

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.tcc.DBConnection.DBUtil;


public class DBConnectionTest {
	

	static DBUtil dbUtil = null;
	static Connection connection=null;
	
	@BeforeClass
	public static void initialise() {
		dbUtil = new DBUtil();
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}

	/**
	 * Test case for Establishing Connection
	 * 
	 * @throws DonorException
	 **/
	@Test
	public void connectTest(){
		connection = dbUtil.getConnection();
		assertNotNull(connection);
	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() 
	{
		connection=null;
		dbUtil=null;
		System.out.println("\t----End of Tests----");
	
	}

}
