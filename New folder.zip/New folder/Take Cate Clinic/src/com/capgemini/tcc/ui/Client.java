package com.capgemini.tcc.ui;

import java.util.Scanner;

import org.apache.log4j.chainsaw.Main;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientADAO;
import com.capgemini.tcc.exception.TackCareClinicException;
import com.capgemini.tcc.service.PatientService;

public class Client {

	
		// TODO Auto-generated constructor stub
	
	 static Scanner scanner = new Scanner(System.in);
	
		
		public static void main(String[] args) 
		{
			PatientBean patientBean = new PatientBean();
			PatientADAO patientADAO = new PatientADAO();
			PatientService patientService = new PatientService();
			while(true)
			{

				System.out.println();
				System.out.println();
				System.out.println(" Take Care Clinic ");
				System.out.println("************************************");
				System.out.println("1.Add Patient Details ");
				System.out.println("2.Search Patient by ID");
				System.out.println("3.Exit");
				System.out.println("***************************************");
				System.out.println("Select an option:");
				
				
				int choice = scanner.nextInt();
				switch (choice)
				{
					case 1:
						System.out.println("Enter the Name of the Patient: ");
						patientBean.setPatient_name(scanner.next());
						
						System.out.println("Enter Age: ");
						patientBean.setAge(scanner.nextInt());
						
						System.out.println("Enter Patient Phone Number: ");
						patientBean.setPhone(scanner.next());
						
						System.out.println("Enter Description: ");
						patientBean.setDescription(scanner.next());
						
					try {
						System.out.println("The patient Informaion stored successfully and PatientId is : "+patientService.addPatientDetails(patientBean));
					} catch (TackCareClinicException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
					
					case 2:
						System.out.println("Search Patient by Id");
						int patientId = scanner.nextInt();
					try {
						System.out.println(patientService.getPatientDetails(patientId).toString());
					} catch (TackCareClinicException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
						
				}

			}
		
		}

}
