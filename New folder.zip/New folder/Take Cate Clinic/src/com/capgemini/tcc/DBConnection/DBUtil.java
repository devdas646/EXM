package com.capgemini.tcc.DBConnection;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;


public class DBUtil {
	private static Connection connection;
	static Logger logger = Logger.getLogger(DBUtil.class);

	public static Connection getConnection() {
		logger.info("start of getConnection method");
		if (connection == null) {
			try {
				FileReader reader = new FileReader("resources\\jdbc.properties");
				Properties properties = new Properties();
				properties.load(reader);
				Class.forName(properties.getProperty("dri"));
				connection = DriverManager.getConnection(
						properties.getProperty("url"),
						properties.getProperty("un"),
						properties.getProperty("pass"));

			} catch (ClassNotFoundException e) {
				logger.error("Problem occured while loading the driver class "+e.getMessage());
				e.printStackTrace();

			} catch (SQLException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		logger.info("end of getConnection method");
		return connection;
	}
	
	public static void main(String[] args) {
		DBUtil dbUtil = new DBUtil();
		System.out.println(dbUtil.getConnection());
	}

}
