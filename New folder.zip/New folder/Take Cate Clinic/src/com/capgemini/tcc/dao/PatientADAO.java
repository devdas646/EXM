package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.tcc.DBConnection.DBUtil;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.TackCareClinicException;

public class PatientADAO implements IPatientDAO{
	

	static Logger logger = Logger.getLogger(PatientADAO.class);
	
	Connection connection=null;
	DBUtil dbutil = new DBUtil();
	
	
	//------------------------ 1. Take Care Clinic Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addPatientDetails(PatientBean patientBean)
			 - Input Parameters	:	PatientBean patientBean
			 - Return Type		:	int
			 - Throws			: 	TackCareClinicException
			 - Author			:	Pravalika
			 - Creation Date	:	12/06/2019
			 - Description		:	Adding PatientDetails
			 ********************************************************************************************************/
	@Override
	public int addPatientDetails(PatientBean patientBean)throws TackCareClinicException 
	{
		logger.info("start of addPatientDetails method");
		connection = dbutil.getConnection();
		ResultSet resultSet;
		int id=0;
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.INSERTQUERY);
			preparedStatement.setString(1, patientBean.getPatient_name());
			preparedStatement.setInt(2, patientBean.getAge());
			preparedStatement.setString(3, patientBean.getPhone());
			preparedStatement.setString(4, patientBean.getDescription());
			preparedStatement.executeUpdate();
			
			
			preparedStatement = null;
			preparedStatement = connection.prepareStatement(QueryMapper.Patient_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
			resultSet.next();
			id=resultSet.getInt(1);
			
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			logger.error("UNABLE TO CONNECT THE DATABASE");
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		logger.info("END OF THE addPatientDetails method");
		return id;
	}

	//------------------------ 1. Take Care Clinic Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getPatientDetails(int patientId)
	 - Input Parameters	:	int patientId
	 - Return Type		:	PatientBean
	 - Throws			: 	TackCareClinicException
	 - Author			:	Pravalika
	 - Creation Date	:	12/06/2019
	 - Description		:	getting PatientDetails by ID
	 ********************************************************************************************************/

	@Override
	public PatientBean getPatientDetails(int patientId)throws TackCareClinicException 
	{

		logger.info("start of getPatientDetails  method");
		connection = dbutil.getConnection();
		PreparedStatement preparedStatement;
		PatientBean patientBean = new PatientBean();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.SEARCHQUERY);		
			preparedStatement.setLong(1, patientId);
			ResultSet resultSet = preparedStatement.executeQuery();
			resultSet.next();
			patientBean.setPatient_id(resultSet.getInt(1));
			patientBean.setPatient_name(resultSet.getString(2));
			patientBean.setAge(resultSet.getInt(3));
			patientBean.setPhone(resultSet.getString(4));
			patientBean.setDescription(resultSet.getString(5));
			patientBean.setConsultation_date(resultSet.getDate(6));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("UNABLE TO CONNECT THE DATABASE");
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		logger.info("END OF THE getPatientDetails  method");
		return patientBean;
	}

}
