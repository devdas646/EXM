package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.TackCareClinicException;

public interface IPatientDAO {
	
	int addPatientDetails( PatientBean patientBean) throws TackCareClinicException;
	PatientBean getPatientDetails(int patientId) throws TackCareClinicException;
	

}
