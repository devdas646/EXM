package com.capgemini.tcc.dao;

public interface QueryMapper {
	public static final String INSERTQUERY = "insert into Patient values(Patient_Id_Seq.nextval,?,?,?,?,sysdate)";
	public static final String SEARCHQUERY = "select * from Patient where patient_id=?";
	public static final String Patient_QUERY_SEQUENCE="SELECT Patient_Id_Seq.CURRVAL FROM DUAL";

}
